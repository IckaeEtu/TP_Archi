$(function() {

    $("#button").click(refreshQuestionnairesList);

    function remplirQuestionnaires(data) {
        console.log(data);
        $('#questionnaires').empty();
        $('#questionnaires').append($('<ul>'));
        if (data && data.questionnaires) {
            for (const questionnaire of data.questionnaires) {
                console.log(questionnaire);
                $('#questionnaires ul')
                  .append($('<li>')
                  .append($('<a>')
                      .text(questionnaire.name)
                          ).on("click", questionnaire, details)
                        );
            }

        } else {
            $('#questionnaires ul').append($('<li>').text("No questionnaires found."));
        }
    }

      function onerror(err) {
          $("#questionnaires").html("<b>Impossible de récupérer les questionnaires !</b>"+err);
      }

    function refreshQuestionnairesList(){
        $("#currentquestionnaire").empty();
        requete = "http://127.0.0.1:5000/quiz/api/v1.0/questionnaires";
        fetch(requete)
        .then( response => {
                  if (response.ok) return response.json();
                  else throw new Error('Problème ajax: '+response.status);
                }
            )
        .then(remplirQuestionnaires)
        .catch(onerror);
      }


    function details(event){
        $("#currentquestionnaire").empty();
        formTask();
        fillFormTask(event.data);
        }


    class Task{
        constructor(name){
            this.name = name;
        }
    }


    $("#tools #add").on("click", formTask);
    $('#tools #del').on('click', delTask);

    function formTask(isnew){
        $("#currentquestionnaire").empty();
        $("#currentquestionnaire")
            .append($('<span>name<input type="text" id="name"><br></span>'))
            .append($('<span><input type="hidden" id="turi"><br></span>'))
            .append(isnew?$('<span><input type="button" value="Save Task"><br></span>').on("click", saveNewTask)
                         :$('<span><input type="button" value="Modify Task"><br></span>').on("click", saveModifiedTask)
                );
        }

    function fillFormTask(t){
        $("#currentquestionnaire #name").val(t.name);
         t.uri=(t.uri == undefined)?"http://127.0.0.1:5000/quiz/api/v1.0/questionnaire"+t.id:t.uri;
         $("#currentquestionnaire #turi").val(t.uri);
    }

    function saveNewTask(){
        var task = new Questionnaire(
            $("#currentquestionnaire #name").val(),
            );
        console.log(JSON.stringify(task));
        fetch("http://127.0.0.1:5000/quiz/api/v1.0/tasks",{
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        method: "POST",
        body: JSON.stringify(task)
            })
        .then(res => { console.log('Save Success') ;
                       $("#result").text(res['contenu']);
                       refreshQuestionnairesList();
                   })
        .catch( res => { console.log(res) });
    }

    function saveModifiedQuestionnaire() {
        const questionnaireName = $('#currentquestionnaire #name').val();
        const questionnaire = { name: questionnaireName };
        const questionnaireUri = $('#currentquestionnaire #turi').val();
    
        console.log("PUT");
        console.log(questionnaireUri);
        console.log(JSON.stringify(questionnaire));
    
        fetch(questionnaireUri, {
            method: "PUT",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(questionnaire)
        })
          .then(response => {
                if (response.ok) {
                    console.log('Update Success');
                    refreshQuestionnaireList();
                } else {
                    console.error('Error updating questionnaire:', response.status);
                }
            })
          .catch(error => {
                console.error('Error updating questionnaire:', error);
            });
    }

    function delTask(){
        if ($("#currentquestionnaire #turi").val()){
        url = $("#currentquestionnaire #turi").val();
        fetch(url,{
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        method: "DELETE"
            })
        .then(res => { console.log('Delete Success:' + res); } )
        .then(refreshQuestionnairesList)
        .catch( res => { console.log(res);  });
    }
  }
});
